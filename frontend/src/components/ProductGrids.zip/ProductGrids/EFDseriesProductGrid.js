import React, { useState } from 'react';
import {
  GridContainer,
  GridItem,
  GridImage,
  Overlay,
  QuoteButton,
  DrawingButton,
  GridTitle,
  ButtonsWrapper,
  ModalOverlay,
  ModalWrapper,
  ModalContent,
  ModalImage,
  CloseButton,
  PDFModalWrapper,
  PDFModalContent,
  PDFIframe,
} from './ProductGridElements';

import GetQuote from './GetQuote';  // Import the GetQuote component

// Import EFD Series Images
import efd10 from '../../images/efdseriesimages/efd-10.jpg';
import efd12 from '../../images/efdseriesimages/efd-12.jpg';
import efd15 from '../../images/efdseriesimages/efd-15.jpg';
import efd20 from '../../images/efdseriesimages/efd-20.jpg';
import efd21 from '../../images/efdseriesimages/efd-21.jpg';
import efd25 from '../../images/efdseriesimages/efd-25.jpg';
import efd30 from '../../images/efdseriesimages/efd-30.jpg';
import efd31 from '../../images/efdseriesimages/efd-31.jpg';
import efd34 from '../../images/efdseriesimages/efd-34.jpg';
import efd40 from '../../images/efdseriesimages/efd-40.jpg';

// Import EFD Series PDFs
import efd10PDF from '../../pdfs/efdseriespdfs/efd-10.pdf';
import efd12PDF from '../../pdfs/efdseriespdfs/efd-12.pdf';
import efd15PDF from '../../pdfs/efdseriespdfs/efd-15.pdf';
import efd20PDF from '../../pdfs/efdseriespdfs/efd-20.pdf';
import efd21PDF from '../../pdfs/efdseriespdfs/efd-21.pdf';
import efd25PDF from '../../pdfs/efdseriespdfs/efd-25.pdf';
import efd30PDF from '../../pdfs/efdseriespdfs/efd-30.pdf';
import efd31PDF from '../../pdfs/efdseriespdfs/efd-31.pdf';
import efd34PDF from '../../pdfs/efdseriespdfs/efd-34.pdf';
import efd40PDF from '../../pdfs/efdseriespdfs/efd-40.pdf';


const products = [
    { id: 1, title: 'EFD-10', img: efd10, pdf: efd10PDF },
    { id: 2, title: 'EFD-12', img: efd12, pdf: efd12PDF },
    { id: 3, title: 'EFD-15', img: efd15, pdf: efd15PDF },
    { id: 4, title: 'EFD-20', img: efd20, pdf: efd20PDF },
    { id: 5, title: 'EFD-21', img: efd21, pdf: efd21PDF },
    { id: 6, title: 'EFD-25', img: efd25, pdf: efd25PDF },
    { id: 7, title: 'EFD-30', img: efd30, pdf: efd30PDF },
    { id: 8, title: 'EFD-31', img: efd31, pdf: efd31PDF },
    { id: 9, title: 'EFD-34', img: efd34, pdf: efd34PDF },
    { id: 10, title: 'EFD-40', img: efd40, pdf: efd40PDF },
  ];
  

const EFDseriesProductGrid = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showPDF, setShowPDF] = useState(false);
  const [pdfSrc, setPdfSrc] = useState('');

  const handleQuoteClick = (product) => {
    setSelectedProduct(product);
  };

  const handleCloseModal = () => {
    setSelectedProduct(null);
  };

  const handleDrawingClick = (product) => {
    setPdfSrc(product.pdf);
    setShowPDF(true);
  };

  const handleClosePDFModal = () => {
    setShowPDF(false);
  };

  return (
    <>
      <GridContainer>
        {products.map((product) => (
          <GridItem key={product.id}>
            <GridImage src={product.img} alt={product.title} />
            <Overlay>
              <ButtonsWrapper>
                <QuoteButton onClick={() => handleQuoteClick(product)}>
                  Get a Quote
                </QuoteButton>
                <DrawingButton onClick={() => handleDrawingClick(product)}>
                  Product Drawing
                </DrawingButton>
              </ButtonsWrapper>
            </Overlay>
            <GridTitle>{product.title}</GridTitle>
          </GridItem>
        ))}
      </GridContainer>

      {selectedProduct && (
        <ModalOverlay>
          <ModalWrapper>
            <ModalContent>
              <ModalImage src={selectedProduct.img} alt={selectedProduct.title} />
              <GetQuote productTitle={selectedProduct.title} /> {/* Use the GetQuote component */}
              <CloseButton onClick={handleCloseModal}>×</CloseButton>
            </ModalContent>
          </ModalWrapper>
        </ModalOverlay>
      )}

      {showPDF && (
        <ModalOverlay>
          <PDFModalWrapper>
            <PDFModalContent>
              <PDFIframe src={pdfSrc} />
            </PDFModalContent>
            <CloseButton onClick={handleClosePDFModal}>×</CloseButton>
          </PDFModalWrapper>
        </ModalOverlay>
      )}
    </>
  );
};

export default EFDseriesProductGrid;
